
adults <- read.table("groupedall.txt", sep=",", dec=".", header=FALSE)

dim(adults)

colnames(adults) <- c('age','workclass','fnlwgt','education','educationnum','maritalstatus','occupation',
                      'relationship','race','sex','capitalgain','capitalloss','hoursperweek','nativecountry','morefifty')

# Clean up column names
colnames(adults) <- make.names(colnames(adults))

adults$morefifty<- as.factor(adults$morefifty)
adults$educationnum<-NULL

adults[["capitalgain"]] <- ordered(cut(adults$capitalgain,c(-Inf, 0, 
                                                            median(adults[["capitalgain"]][adults[["capitalgain"]] >0]), 
                                                            Inf)),labels = c(0,1,2))
adults[["capitalloss"]] <- ordered(cut(adults$capitalloss,c(-Inf, 0, 
                                                            median(adults[["capitalloss"]][adults[["capitalloss"]] >0]), 
                                                            Inf)), labels = c(0,1,2))

summary(adults)


lda.model <- lda (morefifty ~ ., data = adults)

lda.model

adults.pred <- predict(lda.model)

plot(adults.pred$x,type="n")
text(adults.pred$x,labels="o",col=as.integer(adults$morefifty))
legend('bottomright', c("<=50k",">50k"), lty=1, col=c('black', 'red'), bty='n', cex=.75)



tab<-table(adults$morefifty, adults.pred$class)
tab
1 - sum(tab[row(tab)==col(tab)])/sum(tab)

# Let us switch to leave-one-out cross-validation

adults.predcv <- update(lda.model,CV=TRUE)

tab<-table(adults$morefifty,adults.predcv$class)
tab
1 - sum(tab[row(tab)==col(tab)])/sum(tab)




## Quadratic Discriminant Analysis

qda.model <- qda (morefifty ~ ., data = adults)

qda.model

adults.pred <- predict(qda.model)
tab<-table(adults$morefifty, adults.pred$class)
tab
1 - sum(tab[row(tab)==col(tab)])/sum(tab)

# Let us switch to leave-one-out cross-validation

adults.predcv <- update(qda.model,CV=TRUE)
tab<-table(adults$morefifty,adults.predcv$class)
tab
1 - sum(tab[row(tab)==col(tab)])/sum(tab)



## The Naïve Bayes classifier

library (e1071)


N <- nrow(adults)
learn <- sample(1:N, round(2*N/3))

nlearn <- length(learn)
ntest <- N - nlearn

# First we build a model using the learn data

model <- naiveBayes(morefifty ~ ., data = adults[learn,])
model

# compute now the apparent error
pred <- predict(model, adults[learn,-1])

# form and display confusion matrix & overall error
tab <- table(pred, adults[learn,]$morefifty) 
tab
1 - sum(tab[row(tab)==col(tab)])/sum(tab)

# compute the test (prediction) error
pred <- predict(model, newdata=adults[-learn,-1])

# form and display confusion matrix & overall error
tab <- table(Pred=pred, True=adults[-learn,]$morefifty) 
tab
1 - sum(tab[row(tab)==col(tab)])/sum(tab)
